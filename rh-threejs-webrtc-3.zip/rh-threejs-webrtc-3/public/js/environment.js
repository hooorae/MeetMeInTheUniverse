let myMesh;
let myMesh0;

//add stars
let stars = [];


function createEnvironment(scene) {
  console.log("Adding environment");
  
  // for (let i = 0; i < 10; i++){
  //   let texture = new THREE.TextureLoader().load("../assets/texture.png");
  //   ////create balls basic shapes
  //   // let myGeometry = new THREE.SphereGeometry(3, 12, 12);
  //   // let myMaterial = new THREE.MeshBasicMaterial({ map: texture });
  //   // myMesh = new THREE.Mesh(myGeometry, myMaterial);

  //   let myGeometry = new THREE.SphereGeometry( 3, 10, 10 ); //（x横，y高，z长）
  //   let myMaterial = new THREE.MeshBasicMaterial( { map: texture } );
  //   let myMesh = new THREE.Mesh(myGeometry, myMaterial);
  
  //   myMesh.position.set(i*4, 1.5, 10); //括号里数字依次为：x距离，y距离，z距离
  // scene.add(myMesh);
  // }
  // scene.background = new THREE.Color( "rgb(0,0,0)" );
  scene.background = new THREE.TextureLoader().load( "../assets/stars.jpg" );
  
  //////////////////////////////////////////////////////
  //add stars✨
  //////////////////////////////////////////////////////
  let starTexture = new THREE.TextureLoader().load('../assets/shine.jpg');
  for (let i = 0; i < 2000; i++) {
    // let geometry = new THREE.PlaneGeometry( 0.5, 0.5 );
    let geometry = new THREE.SphereGeometry(0.1, 5, 5);
    let material = new THREE.MeshBasicMaterial( { map: starTexture } );
    let star = new THREE.Mesh( geometry, material );
    star.position.set( getRandom(), getRandom(), getRandom() );
    star.material.side = THREE.DoubleSide;
    stars.push( star );
  }
  for (let j = 0; j < stars.length; j++) {
  scene.add( stars[j] );
}

  //images are all from https://www.solarsystemscope.com/textures/
  //adding an earth
  let texture0 = new THREE.TextureLoader().load("../assets/earth.jpg");
  let myGeometry0 = new THREE.SphereGeometry(10, 100, 100 ); //（x横，y高，z长）
  let myMaterial0 = new THREE.MeshBasicMaterial( { map: texture0 } );
  let myMesh0 = new THREE.Mesh(myGeometry0, myMaterial0);
  myMesh0.position.set(0, -10, 0); //括号里数字依次为：x距离，y距离，z距离
  scene.add(myMesh0);


  //adding a sun
  let texture = new THREE.TextureLoader().load("../assets/sun.jpg");
  let myGeometry = new THREE.SphereGeometry( 50, 100, 100 ); //（x横，y高，z长）
  let myMaterial = new THREE.MeshBasicMaterial( { map: texture } );
  let myMesh = new THREE.Mesh(myGeometry, myMaterial);
  myMesh.position.set(200, 2, 10); //括号里数字依次为：x距离，y距离，z距离
  scene.add(myMesh);

  //mercury
  let texture1 = new THREE.TextureLoader().load("../assets/mercury.jpg");
  let myGeometry1 = new THREE.SphereGeometry( 10, 100,100 ); //（x横，y高，z长）
  let myMaterial1 = new THREE.MeshBasicMaterial( { map: texture1 } );
  let myMesh1 = new THREE.Mesh(myGeometry1, myMaterial1);
  myMesh1.position.set(-100, 8, -10); 
  scene.add(myMesh1);

  //venus
  let texture2 = new THREE.TextureLoader().load("../assets/venus.jpg");
  let myGeometry2 = new THREE.SphereGeometry( 10, 100,100); //（x横，y高，z长）
  let myMaterial2 = new THREE.MeshBasicMaterial( { map: texture2 } );
  let myMesh2 = new THREE.Mesh(myGeometry2, myMaterial2);
  myMesh2.position.set(100, 40, -50); 
  scene.add(myMesh2);

  //mars
  let texture3 = new THREE.TextureLoader().load("../assets/mars.jpg");
  let myGeometry3 = new THREE.SphereGeometry(10, 100,100); //（x横，y高，z长）
  let myMaterial3 = new THREE.MeshBasicMaterial( { map: texture3 } );
  let myMesh3 = new THREE.Mesh(myGeometry3, myMaterial3);
  myMesh3.position.set(30, 40, -150); 
  scene.add(myMesh3);

  // jupiter
  let texture4 = new THREE.TextureLoader().load("../assets/jupiter.jpg");
  let myGeometry4 = new THREE.SphereGeometry(8, 100,100); //（x横，y高，z长）
  let myMaterial4 = new THREE.MeshBasicMaterial( { map: texture4 } );
  let myMesh4 = new THREE.Mesh(myGeometry4, myMaterial4);
  myMesh4.position.set(-50, -8, 60); 
  scene.add(myMesh4);

  //saturn
  let texture5 = new THREE.TextureLoader().load("../assets/saturn.jpg");
  let myGeometry5 = new THREE.SphereGeometry(6, 100,100); //（x横，y高，z长）
  let myMaterial5 = new THREE.MeshBasicMaterial( { map: texture5 } );
  let myMesh5 = new THREE.Mesh(myGeometry5, myMaterial5);
  myMesh5.position.set(80, 18, 100); 
  scene.add(myMesh5);

  // //saturn rings
  // let texture6 = new THREE.TextureLoader().load("../assets/saturn_ring.png");
  // let myGeometry6 = new THREE.TorusGeometry(10, 2, 16, 50); //TorusGeometry(radius : Float, tube : Float, radialSegments : Integer, tubularSegments : Integer, arc : Float)
  // let myMaterial6 = new THREE.MeshBasicMaterial( { map: texture6 } );
  // let myMesh6 = new THREE.Mesh(myGeometry6, myMaterial6);
  // myMesh6.position.set(80, 18, 100); 
  // scene.add(myMesh6);

  //uranus
  let texture7 = new THREE.TextureLoader().load("../assets/uranus.jpg");
  let myGeometry7 = new THREE.SphereGeometry(12, 100,100); //（x横，y高，z长）
  let myMaterial7 = new THREE.MeshBasicMaterial( { map: texture7 } );
  let myMesh7 = new THREE.Mesh(myGeometry7, myMaterial7);
  myMesh7.position.set(20, -2, 200); 
  scene.add(myMesh7);

  //neptune
  let texture8 = new THREE.TextureLoader().load("../assets/neptune.jpg");
  let myGeometry8 = new THREE.SphereGeometry(10, 100,100); //（x横，y高，z长）
  let myMaterial8 = new THREE.MeshBasicMaterial( { map: texture8 } );
  let myMesh8 = new THREE.Mesh(myGeometry8, myMaterial8);
  myMesh8.position.set(20, 80, 130); 
  scene.add(myMesh8);

  //moon
  let texture9 = new THREE.TextureLoader().load("../assets/moon.jpg");
  let myGeometry9 = new THREE.SphereGeometry(20, 100,100); //（x横，y高，z长）
  let myMaterial9 = new THREE.MeshBasicMaterial( { map: texture9 } );
  let myMesh9 = new THREE.Mesh(myGeometry9, myMaterial9);
  myMesh9.position.set(80, 30, -100); 
  scene.add(myMesh9);
}

//////////////////////////////////////////////////////
//create random stars
//////////////////////////////////////////////////////
function getRandom(){
  let num = Math.floor(Math.random()*100 +1);
  num *= Math.floor(Math.random()*2) == 1 ? 1 : -1;
  return num;
}

function updateEnvironment(scene) {
  // myMesh.position.x += 0.01;
  // myMesh0.rotation.x += 0.01;
  // myMesh0.rotation.y += 0.01;
}

